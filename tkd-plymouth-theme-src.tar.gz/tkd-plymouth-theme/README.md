Copied and updated from https://aur.archlinux.org/packages/plymouth-theme-arch-logo-gnomishCopied and updated from https://aur.archlinux.org/packages/plymouth-theme-arch-logo-gnomish//
